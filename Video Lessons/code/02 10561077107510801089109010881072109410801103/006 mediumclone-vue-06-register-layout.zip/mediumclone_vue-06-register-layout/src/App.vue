<template>
  <div>
    <h1>Medium clone</h1>

    <router-view></router-view>
  </div>
</template>

<style></style>
