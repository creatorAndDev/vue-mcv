<template>
  <h1>Medium clone</h1>
</template>

<style></style>
