import axios from 'axios'

axios.defaults.baseURL = 'https://conduit.productionready.io/api'

export default axios
